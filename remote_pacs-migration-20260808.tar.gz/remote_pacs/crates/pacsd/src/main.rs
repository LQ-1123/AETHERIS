//! pacsd:PACS 服务端主程序。

mod admin;
mod config;
mod store_handler;
mod tls;

use std::sync::Arc;

use anyhow::{Context, Result};
use axum::Router;
use axum::extract::Request;
use axum::http::{HeaderName, HeaderValue};
use axum::middleware::Next;
use axum::response::Response;
use clap::{Parser, Subcommand, ValueEnum};

use crate::config::Config;
use crate::store_handler::PacsStoreHandler;

#[derive(Parser)]
#[command(name = "pacsd", version = pacs_core::VERSION)]
struct Cli {
    #[command(subcommand)]
    command: Option<Command>,
}

#[derive(Subcommand)]
enum Command {
    /// 创建管理员账号(账号体系的引导入口)
    Admin {
        /// 用户名(小写字母、数字、. _ -,至少 3 个字符)
        #[arg(short, long)]
        username: String,
        /// 密码(至少 12 个字符)
        #[arg(short, long)]
        password: String,
    },
    /// 管理登录用户
    User {
        #[command(subcommand)]
        command: UserCommand,
    },
}

#[derive(Subcommand)]
enum UserCommand {
    /// 创建指定角色的登录账号
    Create {
        /// 用户名(小写字母、数字、. _ -,至少 3 个字符)
        #[arg(short, long)]
        username: String,
        /// 初始密码(12 到 128 个字符)
        #[arg(short, long)]
        password: String,
        /// 账号角色
        #[arg(short, long, value_enum)]
        role: CliRole,
    },
}

#[derive(Clone, Copy, Debug, ValueEnum)]
enum CliRole {
    Admin,
    Radiologist,
    Technician,
    Viewer,
}

impl From<CliRole> for pacs_auth::Role {
    fn from(role: CliRole) -> Self {
        match role {
            CliRole::Admin => Self::Admin,
            CliRole::Radiologist => Self::Radiologist,
            CliRole::Technician => Self::Technician,
            CliRole::Viewer => Self::Viewer,
        }
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();
    let config = Config::from_env()?;

    let pool = pacs_db::connect(&config.database_url)
        .await
        .context("连接数据库失败")?;
    pacs_db::migrate(&pool)
        .await
        .context("应用数据库迁移失败")?;

    match cli.command {
        Some(Command::Admin { username, password }) => {
            admin::create_admin(&pool, &username, &password).await?;
            return Ok(());
        }
        Some(Command::User {
            command:
                UserCommand::Create {
                    username,
                    password,
                    role,
                },
        }) => {
            admin::create_user(&pool, &username, &password, role.into()).await?;
            return Ok(());
        }
        None => {
            // 无子命令:启动服务
        }
    }

    pacs_db::reset_observed_dicom_associations(&pool)
        .await
        .context("重置 DIMSE 入站连接状态失败")?;

    for addr in config.binds_beyond_loopback() {
        tracing::warn!(
            %addr,
            "监听地址超出回环。DIMSE 和 HTTP 现已启用认证,但请注意网络安全"
        );
    }

    let store = pacs_store::Store::open(&config.storage_root)
        .await
        .context("打开影像存储根失败")?;
    let removed = store.cleanup_temp().await.context("清理临时文件失败")?;

    // TLS 证书
    let tls_certs = tls::TlsCerts::ensure(&config.storage_root)
        .await
        .context("TLS 证书初始化失败")?;

    // 认证服务
    // 变量名跟随 `PACS_` 前缀的统一约定(见 .env.example)。
    // 名字和配置文件对不上会让配好的密钥被静默忽略 —— debug 构建悄悄回退到
    // 开发默认值,release 构建则在用户明明配了变量的情况下 panic。
    let jwt_secret = std::env::var("PACS_JWT_SECRET").unwrap_or_else(|_| {
        let default = "dev-secret-DO-NOT-USE-IN-PRODUCTION";
        if cfg!(debug_assertions) {
            tracing::warn!(
                "PACS_JWT_SECRET 未设置，使用开发默认值（生产环境请用 `openssl rand -base64 48` 生成）"
            );
            default.to_string()
        } else {
            panic!("生产构建必须设置 PACS_JWT_SECRET 环境变量");
        }
    });
    let auth_service = Arc::new(
        pacs_auth::AuthService::new(pool.clone(), jwt_secret.as_bytes())
            .context("认证服务初始化失败")?,
    );

    // HTTP 路由。/auth 不鉴权(登录本身就是取令牌的入口),
    // /dicomweb 整棵子树要求 ViewImages。
    let shared_store = Arc::new(store.clone());
    let api_state = pacs_web::WebState::with_store(pool.clone(), shared_store.clone())
        .with_dicom_node(config.ae_title.clone(), config.dimse_bind);
    let transform_state = api_state.clone();
    let _transform_worker = pacs_web::start_transform_worker(transform_state.clone());
    let _transfer_worker = pacs_web::start_transfer_worker(transform_state.clone());
    let _router_worker = pacs_web::start_router_worker(transform_state.clone());
    let _lifecycle_worker = pacs_web::start_lifecycle_worker(transform_state.clone());
    let api_routes = pacs_web::worklist_routes(api_state.clone(), auth_service.clone())
        .merge(pacs_web::annotation_routes(
            api_state.clone(),
            auth_service.clone(),
        ))
        .merge(pacs_web::segmentation_routes(
            api_state.clone(),
            auth_service.clone(),
        ))
        .nest(
            "/dicom",
            pacs_web::dicom_transformation_routes(api_state.clone(), auth_service.clone()),
        );
    let http_app = Router::new()
        .nest("/auth", pacs_auth::http::routes(auth_service.clone()))
        .nest(
            "/api/v1",
            pacs_auth::service_accounts::management_routes(auth_service.clone())
                .merge(pacs_auth::service_accounts::service_routes(
                    auth_service.clone(),
                ))
                .merge(pacs_auth::service_accounts::documentation_routes())
                .merge(pacs_web::transfer_routes(
                    transform_state.clone(),
                    auth_service.clone(),
                ))
                .merge(pacs_web::router_routes(
                    transform_state.clone(),
                    auth_service.clone(),
                ))
                .merge(pacs_web::lifecycle_routes(
                    transform_state,
                    auth_service.clone(),
                )),
        )
        .nest(
            "/dicomweb",
            pacs_web::dicomweb_routes(
                // Store 里只有一个 PathBuf,克隆便宜;包进 Arc 是让 WADO 的
                // handler 和 DIMSE 的 store handler 共用同一份存储根配置
                pacs_web::WebState::with_store(pool.clone(), shared_store)
                    .with_dicom_node(config.ae_title.clone(), config.dimse_bind),
                auth_service.clone(),
            ),
        )
        .nest("/api", api_routes)
        .fallback(|| async { axum::http::StatusCode::NOT_FOUND })
        .layer(axum::middleware::from_fn(request_id));

    // DIMSE 监听
    let dimse = pacs_dimse::DimseServer::bind(pacs_dimse::ServerConfig::new(
        config.dimse_bind,
        &config.ae_title,
    ))
    .await
    .with_context(|| format!("DIMSE 无法监听 {}", config.dimse_bind))?;

    let dimse_handler = Arc::new(PacsStoreHandler::new(store, pool));

    tracing::info!(
        version = pacs_core::VERSION,
        storage_root = %config.storage_root.display(),
        ae_title = %config.ae_title,
        dimse_bind = %config.dimse_bind,
        http_bind = %config.http_bind,
        recovered_temp_files = removed,
        ca_cert = %tls_certs.ca_cert_path.display(),
        "pacsd 就绪（HTTPS 已启用）"
    );

    // 同时运行 DIMSE 和 HTTPS
    let dimse_task = tokio::spawn(async move {
        if let Err(e) = dimse.run(dimse_handler).await {
            tracing::error!(error = ?e, "DIMSE 服务异常退出");
        }
    });

    let https_task = tokio::spawn(async move {
        let tls_config = axum_server::tls_rustls::RustlsConfig::from_pem_file(
            &tls_certs.server_cert_path,
            &tls_certs.server_key_path,
        )
        .await
        .context("加载 TLS 证书失败")
        .unwrap();

        axum_server::bind_rustls(config.http_bind, tls_config)
            .serve(http_app.into_make_service())
            .await
            .context("HTTPS 服务异常退出")
            .unwrap();
    });

    tokio::select! {
        _ = dimse_task => {},
        _ = https_task => {},
    }

    Ok(())
}

async fn request_id(mut request: Request, next: Next) -> Response {
    static X_REQUEST_ID: HeaderName = HeaderName::from_static("x-request-id");
    let value = HeaderValue::from_str(&uuid::Uuid::new_v4().to_string())
        .expect("UUID 必须是合法 HTTP header");
    request
        .headers_mut()
        .insert(X_REQUEST_ID.clone(), value.clone());
    let mut response = next.run(request).await;
    response.headers_mut().insert(X_REQUEST_ID.clone(), value);
    response
}

#[cfg(test)]
mod cli_tests {
    use super::*;
    use clap::error::ErrorKind;

    #[test]
    fn user_create_accepts_every_role() {
        let cases = [
            ("admin", pacs_auth::Role::Admin),
            ("radiologist", pacs_auth::Role::Radiologist),
            ("technician", pacs_auth::Role::Technician),
            ("viewer", pacs_auth::Role::Viewer),
        ];

        for (raw, expected) in cases {
            let cli = Cli::try_parse_from([
                "pacsd",
                "user",
                "create",
                "--username",
                "alice",
                "--password",
                "a-secure-password",
                "--role",
                raw,
            ])
            .expect("角色应能解析");

            let Some(Command::User {
                command: UserCommand::Create { role, .. },
            }) = cli.command
            else {
                panic!("应解析为 user create");
            };
            assert_eq!(pacs_auth::Role::from(role), expected);
        }
    }

    #[test]
    fn user_create_rejects_unknown_role() {
        let error = Cli::try_parse_from([
            "pacsd",
            "user",
            "create",
            "--username",
            "alice",
            "--password",
            "a-secure-password",
            "--role",
            "superuser",
        ])
        .err()
        .expect("未知角色必须被拒绝");

        assert_eq!(error.kind(), ErrorKind::InvalidValue);
    }

    #[test]
    fn legacy_admin_command_remains_available() {
        let cli = Cli::try_parse_from([
            "pacsd",
            "admin",
            "--username",
            "first-admin",
            "--password",
            "a-secure-password",
        ])
        .expect("旧的管理员引导命令应保持兼容");

        assert!(matches!(cli.command, Some(Command::Admin { .. })));
    }
}
